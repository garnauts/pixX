<?php
// Text
$_['text_title']       = 'Pix - %s';
$_['text_instruction'] = 'Instruções para o pagamento por Pix';
$_['text_payable']     = 'Transfira para a seguinte Chave Pix: ';
$_['text_customer_pix']    =  '<p>Se você escolheu pagar por <b>Pix</b>, certifique-se de que tenha feito pagameto para a chave <b>%s</b></p>';