<?php
// Text
$_['text_title']       = 'Pix / Money Order';
$_['text_instruction'] = 'Pix / Money Order Instructions';
$_['text_payable']     = 'Make Payable To: ';
$_['text_customer_pix']    =  '<p>If you payment witch <b>Pix</b>, pay for <b>%s</b></p>';