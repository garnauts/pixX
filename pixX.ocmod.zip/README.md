# pixX
Projeto open-source para extensão de pagamentos por meio de PIX para a plataforma de e-commerce opencart
